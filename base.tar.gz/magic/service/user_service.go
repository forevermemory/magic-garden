package service

/*
date:2020-07-29 14:00:32
*/

import (
	"errors"
	"magic/db"
	"magic/global"
	utils "magic/utils"

	"github.com/gomodule/redigo/redis"
)

// RegisterUser 注册用户
func RegisterUser(req *global.RegisteruserParams) error {
	// 1.校验code是否正确
	conn := global.REDIS.Get()
	defer conn.Close()
	code, err := redis.String(conn.Do("get", req.Phone))
	if err != nil {
		return err
	}
	if code != req.Code {
		return errors.New("验证码不正确")
	}
	// 2. 注册用户
	user := &db.Users{
		Username: req.Username,
		Password: req.Password,
		Phone:    req.Phone,
	}
	if err = db.AddUsers(user); err != nil {
		return err
	}
	// 3.删除redis的code
	if _, err = conn.Do("del", req.Phone); err != nil {
		return err
	}
	return nil
}

// RegisterUserSendMsg 发短信
func RegisterUserSendMsg(phone string) (string, error) {
	// 校验手机号吧
	if ok := utils.CheckIsPhoneVaild(phone); !ok {
		return "", errors.New("手机号不合理")
	}
	code := utils.GenValidateCode(4)
	utils.SendQiniuCode(code, phone)
	// 将验证码放到redis TODO key 手机号 val code
	conn := global.REDIS.Get()
	defer conn.Close()
	if _, err := conn.Do("set", phone, code); err != nil {
		return "", err
	}
	// 不设置过期时间
	return code, nil
}

// AddUsers add
func AddUsers(b *db.Users) error {
	return db.AddUsers(b)
}

// UpdateUsers update
func UpdateUsers(b *db.Users) error {
	return db.UpdateUsers(b)
}

// GetUsersByID get by id
func GetUsersByID(id int) (*db.Users, error) {
	return db.GetUsersByID(id)
}

// ListUsers  page by condition
func ListUsers(b *db.Users) (*db.DataStore, error) {
	list, err := db.ListUsers(b)
	if err != nil {
		return nil, err
	}
	total, err := db.CountUsers(b)
	if err != nil {
		return nil, err
	}
	return &db.DataStore{Total: total, Data: list, TotalPage: (int(total) + b.PageSize - 1) / b.PageSize}, nil
}

// DeleteUsers delete
func DeleteUsers(id int) error {
	return db.DeleteUsers(id)
}
