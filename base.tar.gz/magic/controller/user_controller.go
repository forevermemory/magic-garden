package controller

/*
date:2020-07-29 14:00:32
*/

import (
	"magic/db"
	"magic/global"
	"magic/service"

	"github.com/gin-gonic/gin"
)

// RegisteUsers 注册
func RegisteUsers(c *gin.Context) interface{} {
	phone, ok := c.GetQuery("phone")
	if !ok {
		return ErrorResponse{-1, "请传入手机号phone参数"}
	}
	code, err := service.RegisterUserSendMsg(phone)
	if err != nil {
		return ErrorResponse{-1, err.Error()}
	}
	res := Response{"ok", gin.H{"code": code}}
	return OKResponse{0, res}
}

// AddUsers add
func AddUsers(c *gin.Context) interface{} {

	var u = global.RegisteruserParams{}
	err := c.ShouldBind(&u)
	if err != nil {
		return ErrorResponse{-1, err.Error()}
	}
	err = service.RegisterUser(&u)
	if err != nil {
		return ErrorResponse{-1, err.Error()}
	}
	return OKResponse{0, "ok"}
}

// UpdateUsers update
func UpdateUsers(c *gin.Context) interface{} {
	var u = db.Users{}
	err := c.ShouldBind(&u)
	if err != nil {
		return ErrorResponse{-1, err.Error()}
	}
	err = service.UpdateUsers(&u)
	if err != nil {
		return ErrorResponse{-1, err.Error()}
	}
	return OKResponse{0, "ok"}
}

// GetUsersByID  get xxx by id
func GetUsersByID(c *gin.Context) interface{} {
	var u = db.Users{}
	err := c.ShouldBind(&u)
	if err != nil {
		return ErrorResponse{-1, err.Error()}
	}
	data, err := service.GetUsersByID(u.ID)
	if err != nil {
		return ErrorResponse{-1, err.Error()}
	}
	return OKResponse{0, data}
}

// ListUsers // list by page condition
func ListUsers(c *gin.Context) interface{} {
	var u = db.Users{PageSize: 10, PageNo: 1}
	err := c.ShouldBind(&u)
	if err != nil {
		return ErrorResponse{-1, err.Error()}
	}
	data, err := service.ListUsers(&u)
	if err != nil {
		return ErrorResponse{-1, err.Error()}
	}
	return OKResponse{0, data}
}

// DeleteUsers Delete
func DeleteUsers(c *gin.Context) interface{} {
	var u = db.Users{}
	err := c.ShouldBind(&u)
	if err != nil {
		return ErrorResponse{-1, err.Error()}
	}
	err = service.DeleteUsers(u.ID)
	if err != nil {
		return ErrorResponse{-1, err.Error()}
	}
	return OKResponse{0, "ok"}
}
